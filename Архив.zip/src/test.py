print("Hello, World!")
import sys
print(f"Python version: {sys.version}")
print("This is a test script.")